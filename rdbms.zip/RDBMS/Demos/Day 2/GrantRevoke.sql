USE AdventureWorks;
GRANT CREATE TABLE TO MelanieK;
GO
