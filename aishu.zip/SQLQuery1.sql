create schema [190305]

create table [190305].Employee
(
	EmpId int primary key identity,
	EmpName varchar(30),
	Doj date,
	MobileNo char(10),
	Salary money,
)

create table Employee
(
	EmpId int primary key identity, --we can pass seed value as 1 and increment value as 1 identity(10001,1) 
									--identiy function is just for table and not for columns,there can be only one identity
	EmpName varchar(30),
	Doj date,
	MobileNo char(10),
	Salary money,
)

--drop table abc.Employee

insert into [190305].Employee values('Aishwarya','07-18-2019','1234567890',20000,3)
insert into [190305].Employee values('Aishwarya','05-18-2019','1234567890',20000,4)
select * from [190305].Employee

EXEC sp_help '[190305].Employee'

SELECT USER_NAME(1)

SELECT * FROM INFORMATION_SCHEMA.TABLES

CREATE SEQUENCE SQ1 AS INT
START WITH 101
INCREMENT BY 1
MINVALUE 101
MAXVALUE 301
CYCLE
GO

SELECT NEXT VALUE FOR SQ1

CREATE SEQUENCE SQ2 AS INT
START WITH 101
INCREMENT BY 100
MINVALUE 101
MAXVALUE 301
CYCLE
GO

SELECT NEXT VALUE FOR SQ2

create table [190305].Marks1
(
Test1 int ,Test2 int,
TestAvg As (Test1 +Test2)/2)

insert into  [190305].Marks1  values(20,30)
select * from [190305].Marks1

Create table [190305].Printer(PrinterId int Identity(1000,1)Not Null)
select * from [190305].Printer

Create table [190305].Customer(CustomerId uniqueidentifier Not Null)
Insert into [190305].Customer Values (NewId())
select * from [190305].Customer

create table [190305].emp
(EmpName varchar(30) Not Null,
Salary int ,
DateofJoining Date)
drop table [190305].emp

insert into [190305].Employee(EmpName,Salary,Doj) values('Aishu',20000,'07-18-2018')
insert into [190305].Employee(EmpName,Salary,Doj) values('Aishu',10000,'07-18-2019')

select * from [190305].Employee

delete from [190305].Employee where Doj = '07-18-2019'

alter table [190305].Employee
alter column MobileNo char(10) Not Null

alter table [190305].Employee
add DeptId int

create table [190305].Department
(
	DeptId int Primary key IDENTITY,
	DeptName varchar(30)
)

insert into [190305].Department values('Admin'),('HR')
select * from [190305].Department


alter table [190305].Employee
Add constraint FK_dept_dept
Foreign key(DeptId)
References [190305].Department(DeptId)

create type Region			-- User defined type / alias
from varchar(15) Not NUll

create default Df_value as 'Na' --create default
exec sp_bindefault 'Df_value','Region';

create table temp1( Id int,Region Region)
insert into temp1 values(1,'Mumbai')
insert into temp1(Id) values(2)

select * from temp1
select * from [190305].Employee

Update [190305].Employee set Salary = (Salary + 1000) where Doj = '07/18/2018'

declare @abc int = 5
Update [190305].Employee set Salary = Salary + @abc 


create table [190305].StudentSource( StudentId int primary key, StudentName varchar(25))
Insert into [190305].StudentSource values(1,'Aishu')
Insert into [190305].StudentSource values(2,'Suji')

create table [190305].StudentTarget( StudentId int primary key, StudentName varchar(25))
Insert into [190305].StudentTarget values(1,'S Aishu')
Insert into [190305].StudentTarget values(3,'Meghna')

alter table [190305].StudentSource
Add constraint FK_dept_dept
Foreign key(StudentId)
References [190305].StudentTarget(StudentId)

select * from [190305].StudentSource
select * from [190305].StudentTarget

Merge INTO [190305].StudentSource As S
using [190305].StudentTarget As T
on T.StudentId = S.StudentId
When matched then
	Update Set S.StudentName = T.StudentName
When not matched then
	Insert (StudentId,StudentName) values(T.StudentId , T.StudentName);

SELECT EmpId , EmpName Doj from [190305].Employee
Order by Doj Desc

---- another db
--use Northwind 
--Select DISTINCT dept_name
--from Northwind.dbo.staff_master

declare @no int = 10000;
print len(@no);

declare @name varchar(30) = 'Aishwarya Shiva';
print SUBSTRING(@name,1,10)

declare @d1 datetime = GetDate()
declare @d2 datetime = DateAdd(MONTH,1,@d1)
select @d2
select DATEDIFF(day,@d1,@d2);

Select HOST_NAME()
Select HOST_ID()
Select USER_NAME()

select DeptId , Avg(Salary) from [190305].Employee group by Salary, DeptId

--average experience of employees from particular department using where clause
--average experience of employees from all department using group by clause