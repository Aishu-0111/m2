--Lab 1

use Training_18Jul19_Pune
go

sp_help
go

select @@VERSION
select GETDATE()

use Northwind
sp_help staff_master

select staff_name , Dept_code from staff_master


--1.3

use Training_18Jul19_Pune

create Schema [190305]

create table [190305].Customers
(	
	CustomerName varchar(20) Not NUll Unique,
	Address1 varchar(30) ,
	Address2 varchar(30) ,
	Contactnumber varchar(12) Not null,
	PostalCode varchar(10)
)

create table [190305].Employees
(
	EmployeeId int Not Null Primary Key,
	Name nvarchar(255) Null
)

create table [190305].Contractor
(
	ContractorId int Not Null Primary Key,
	Name nvarchar(255) Null
)

create table [190305].TestRethrow
(
	Id int primary key
)

create table dbo.TestRethrow
(
	Id int primary key
)

create type Region		-- User defined type / alias
from varchar(15) Not NUll

create default DFVALUE as 'NA' --create default
exec sp_bindefault 'DFVALUE','Region';

alter table [190305].Customer
add Customer_Region Region 

alter table [190305].Customer
add Gender varchar(1)

alter table [190305].Customer
Add constraint gender_check
Check(Gender = 'M' or Gender = 'F')

create table [190305].Orderss
(
	OrdersID Int NOT NULL IDENTITY(1000,1),
	Customerld Int Not Null Primary key,
	OrdersDate Datetime,
	Order_State varchar(1) Check ( Order_State = 'P' or Order_State = 'C')
)

alter table [190305].Customer
Add constraint fk_CustOrders
Foreign key(CustomerId)
References [190305].Orderss(CustomerId)

exec sp_help '[190305].Customer'

USE Training_18Jul19_Pune
CREATE SEQUENCE IdSequence AS INT
START WITH 10000
INCREMENT BY 1;

insert into [190305].Employees(EmployeeId ,Name) values (Next value for IdSequence ,'Aishu');
insert into [190305].Contractor(ContractorId ,Name) values (Next value for IdSequence ,'Abc');

select * from [190305].Employees
select * from [190305].Contractor

--1.4

use Training
create schema University

select Student_Code , Student_Name , Department_Code from [University].Student
select Staff_Code , Staff_Name , Department_Code from [University].Staff
select Employee_Name , Salary , DEPT from [University].Employee where DEPT = 20 or DEPT = 30 or DEPT = 40
-- 1.4 4 left
